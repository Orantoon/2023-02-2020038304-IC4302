#!/bin/bash


helm uninstall backups

helm uninstall databases

helm uninstall bootstrap

